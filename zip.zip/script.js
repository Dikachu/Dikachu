const locationTitle = document.querySelector('.location h1')
const cloud = document.querySelector('.locationDiv h1')
const currentDate = document.querySelector('.location p')
const weather_icon = document.querySelector('.weather_icon img')
const condition = document.querySelector('.condition')
const forecastDiv = document.querySelector('.forecast')
const cloudyImg = document.querySelector('.cloudy img')
const inputs = document.querySelectorAll('input')
const clearSearch = document.querySelectorAll('.inputDiv img')
const conditionValues = [...document.querySelectorAll('.value_and_icon span')]
// console.log(clearSearch);



async function weather(area) {
    const API_KEY  = 'dff4ac26e1724f6e84d161912241311';
    const API_URL = 'http://api.weatherapi.com/v1/forecast.json';
    
    const response = await fetch(`${API_URL}?key=${API_KEY}&q=${area}&days=1&aqi=no&alerts=no`);
    
    if (response.ok != true) {
        throw new Error('Error fetching')
    }
    
    const data = await response.json();
    // console.log(data);

    const location = data.location
    const current = data.current
    const forecast = data.forecast.forecastday[0]
    const hour = data.forecast.forecastday[0].hour


    // Filling up the gotten value accordingly (current)

    cloud.innerText =   `${current.cloud}°`
    locationTitle.innerText = location.name
    currentDate.innerText = `${new Date(current.last_updated).toLocaleTimeString()} ${new Date(current.last_updated).toDateString()}`;
    weather_icon.src = `https://${current.condition.icon}`
    condition.innerText = current.condition.text
    conditionValues[0].innerText = `${Math.floor(current.temp_c)}°`
    conditionValues[1].innerText = `${Math.floor(current.temp_f)}°`
    conditionValues[2].innerText = `${current.humidity}%`
    conditionValues[3].innerText = `${current.cloud}°`
    conditionValues[4].innerText = `${current.wind_degree}%`
    conditionValues[5].innerText = current.wind_dir
    conditionValues[6].innerText = current.pressure_in
    cloudyImg.src = `https://${current.condition.icon}`

    // Filling up the gotten value accordingly (forecast)

    hour.forEach(times => {
        const time_forecast = document.createElement('div')
        time_forecast.classList.add('time_forecast')

        time_forecast.innerHTML = `
            <div class="timesDiv">
                <img src="https://${times.condition.icon}" alt="">
                <div class="time_and_weather">
                    <h1>${new Date(times.time).toLocaleTimeString()}</h1>
                    <p>${times.condition.text}</p>
                </div>
            </div>
            <h1>${times.cloud}°</h1>
        `
        forecastDiv.append(time_forecast)
        // forecastDiv.innerHTML = time_forecast
    });

}



inputs.forEach(input => {
    input.addEventListener('change', (e)=>{
        const inputValue = e.target.value
        const inputValueLen = inputValue.length
    
        if(inputValueLen >= 3){
            forecastDiv.innerHTML = `<h1 class="forecast_tittle">forecast details</h1>`
            weather(inputValue)
        }
    })
});

clearSearch.forEach(clear => {
    clear.addEventListener('click', (e)=>{
        const clicked = e.target

        clicked.previousElementSibling.value = ''
    })
});


function getCityName() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(success, error);
    } else {
        console.log("Geolocation is not supported by this browser.");
    }
}

function success(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;
    // console.log(latitude, longitude);
    
    getCityFromCoordinates(latitude, longitude);
}

function error() {
    console.log("Unable to retrieve your location.");
}

async function getCityFromCoordinates(lat, lon) {
    const apiKey = '89d446526b094221997ba3fb34a2d942';
    const response = await fetch(`https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lon}&key=${apiKey}`);
    const data = await response.json();

    // console.log(data);
    

    if (data.results && data.results.length > 0) {
        const city = data.results[0].components.city
        weather(city)
    } else {
        console.log("City not found");
    }
}

getCityName()

// weather('nsukka')

